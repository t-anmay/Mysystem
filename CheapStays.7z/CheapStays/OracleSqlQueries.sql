CREATE TABLE users(user_id varchar(4), 
		  password varchar(7), 
                  role varchar(10), 
                  user_name varchar (20), 
                  mobile_no varchar(10), 
                  phone varchar(10), 
                  address varchar(25),
                  email varchar(15));
  
CREATE SEQUENCE users_seq START WITH 100;


2.

CREATE TABLE Hotels(hotel_id varchar(4), 
	city varchar(10), 
	hotel_name varchar (30), 
	address varchar(35), 
	description varchar(50), 
	avg_rate_per_night number(7,2), 
	phone_no1 varchar(10),
 	phone_no2 varchar(10),
 	rating varchar(4), 
	email varchar(30),
        fax varchar(15));


INSERT INTO Hotels VALUES('A101','Pune','City View Hotel','Pimple Saudagar','Located amidst mountains',15000.00,'9856741232',
'7789564256','4','cityviewhotel@gmail.com','011235');

INSERT INTO Hotels VALUES('A102','Mumbai','Hotel Mount View','Andheri East','Located near beach',20000.00,'9856741231',
'7789564244','5','hotelmountview@gmail.com','011785');
