package com.capgemini.cheapstays.model.dao;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.exception.HotelException;


public interface HotelsDAO {
	
	public Hotel searchHotel(Hotel hotel) throws HotelException;

}
