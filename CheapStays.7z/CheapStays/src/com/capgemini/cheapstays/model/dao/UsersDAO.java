package com.capgemini.cheapstays.model.dao;

import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.UsersException;


public interface UsersDAO {
	public void addUsers(Users user) throws UsersException;
	
	public boolean validateUser(Users user) throws UsersException;
	

}
