package com.capgemini.cheapstays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.factory.DBUtil;

public class HotelsDAOImpl implements HotelsDAO {

	
	/**
	 *  Searching Hotels by hotel_id.
	 * 
	 */
	
	
	
	@Override
	public Hotel searchHotel(Hotel hotel) throws HotelException {
		
		try (Connection con = DBUtil.getConnection()){
			
			PreparedStatement pstm = 
					con.prepareStatement("select * from Hotels where hotel_id =?");
			
			pstm.setString(1, hotel.getHotel_id());
			
			ResultSet res = pstm.executeQuery();
			 hotel.setCity(res.getString(2));
			 
			 System.out.println("HotelCity .........."+hotel.getCity());
			
			
			System.out.println("Res.................... "+res);
			
			if(res.next() != true) {
				throw new HotelException("Hotel not found with this id "+hotel.getHotel_id());
			
		 } else {
			 
			 hotel.setHotel_id(res.getString("HOTEL_ID"));
			 hotel.setCity(res.getString("CITY"));
			 hotel.setHotel_name(res.getString("HOTEL_NAME"));
			 hotel.setAddress(res.getString("ADDRESS"));
			 hotel.setDescription(res.getString("DESCRIPTION"));
			 hotel.setAvg_rate_per_night(res.getFloat("AVG_RATE_PER_NIGHT"));
			 hotel.setPhone_no1(res.getString("PHONE_NO1"));
			 hotel.setPhone_no2(res.getString("PHONE_NO2"));
			 hotel.setRating(res.getString("RATING"));
			 hotel.setEmail(res.getString("EMAIL"));
			 hotel.setFax(res.getString("FAX"));
			 
			 System.out.println("Hotel in dao"+hotel);
			 return hotel; 
		 }	
			
	} catch(Exception e) {
		throw new HotelException(e);
	}		
			
	
	} // end of searchHotel......
		
	
	
	
}


