package com.capgemini.cheapstays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.factory.DBUtil;


public class UsersDAOImpl implements UsersDAO {

	@Override
	public void addUsers(Users user) throws UsersException {
		try(Connection con=DBUtil.getConnection()) {
			
			PreparedStatement pstm=con.prepareStatement("insert into users values(users_seq.nextval,?,?,?,?,?,?,?)");
			
		
			pstm.setString(1, user.getPassword());
			pstm.setString(2, user.getRole());
			pstm.setString(3, user.getUser_name());
			pstm.setString(4,user.getMobile_no());
			pstm.setString(5, user.getPhone());
			pstm.setString(6, user.getAddress());
			pstm.setString(7, user.getEmail());
			
			pstm.executeUpdate();
			
			
		} catch (Exception e) {
			throw new UsersException(e);
		}
		
	}

	@Override
	public boolean validateUser(Users user) throws UsersException {
		try(Connection con=DBUtil.getConnection()) {
			
			PreparedStatement pstm=con.prepareStatement("select * from users where user_name=? and password=?");
			
			pstm.setString(1, user.getUser_name());
			pstm.setString(2, user.getPassword());
			
			ResultSet res= pstm.executeQuery();
			
			if(res.next()==false)
			{
				throw new UsersException("Username or password is wrong");
			}
			else
			{
				return true;
			}
			
		} catch (Exception e) {
			throw new UsersException(e.getMessage());
		}
	}

}
