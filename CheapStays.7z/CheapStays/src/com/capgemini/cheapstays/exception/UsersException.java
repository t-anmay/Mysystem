package com.capgemini.cheapstays.exception;

public class UsersException extends Exception {

	public UsersException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UsersException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UsersException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
