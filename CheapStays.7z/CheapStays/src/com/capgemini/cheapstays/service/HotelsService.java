package com.capgemini.cheapstays.service;

import java.util.HashMap;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.UsersException;


public interface HotelsService {
	
	
	
	public Hotel searchHotel(String hotel_id) throws HotelException;
	
	public void addUsers(HashMap<String,String> userDetails) throws UsersException;
	
	public boolean validateUser(String username, String password) throws UsersException;
}
