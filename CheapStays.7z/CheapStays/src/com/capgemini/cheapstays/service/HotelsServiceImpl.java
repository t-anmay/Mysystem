package com.capgemini.cheapstays.service;

import java.util.HashMap;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.model.dao.HotelsDAO;
import com.capgemini.cheapstays.model.dao.HotelsDAOImpl;
import com.capgemini.cheapstays.model.dao.UsersDAO;
import com.capgemini.cheapstays.model.dao.UsersDAOImpl;


public class HotelsServiceImpl implements HotelsService {
	
	private UsersDAO usersDAO;
	private HotelsDAO hotelDAO;
	
	public HotelsServiceImpl() {
		usersDAO=new UsersDAOImpl();
		hotelDAO =new HotelsDAOImpl();
	}

	@Override
	public void addUsers(HashMap<String, String> userDetails)
			throws UsersException {
		
		Users user= new Users();
		
		
		user.setPassword(userDetails.get("password"));
		user.setRole(userDetails.get("role"));
		user.setUser_name(userDetails.get("user_name"));
		user.setMobile_no(userDetails.get("mobile_no"));
		user.setPhone(userDetails.get("phone"));
		user.setAddress(userDetails.get("email"));
		
		usersDAO.addUsers(user);
		
		
	} //end of addUsers...

	@Override
	public boolean validateUser(String username, String password) throws UsersException {
		
		Users user=new Users();
		user.setUser_name(username);
		user.setPassword(password);
	
		return usersDAO.validateUser(user);
	} //end of validateUsers....

	
	
	@Override
	public Hotel searchHotel(String hotel_id) throws HotelException {
		
			Hotel hotel = new Hotel();
			hotel.setHotel_id(hotel_id);
			
			Hotel foundHotel = hotelDAO.searchHotel(hotel);
			System.out.println("IN service foundHotel " +foundHotel);
			return foundHotel;
		
	}

}
