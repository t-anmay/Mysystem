package com.capgemini.cheapstays.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.service.HotelsService;
import com.capgemini.cheapstays.service.HotelsServiceImpl;


@WebServlet("/UsersFrontController")
public class UsersFrontController extends HttpServlet {
	
	private HotelsService hotelService;
       
  
    public UsersFrontController() {
    	hotelService = new HotelsServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//	HttpSession usersession = request.getSession(false);
		
//		if(usersession == null)
//		{
//			RequestDispatcher rd= request.getRequestDispatcher("Error.jsp");
//			request.setAttribute("errorMessage", "You need to login to access this page."+"<a href='Login.jsp'>Click Here</a> to login.");
//			rd.forward(request, response);
//			return;
//		}
		
		
		
		
		String action= request.getParameter("action");
		
		switch(action)
		{
			case "add":
			{
				
				String password=request.getParameter("password");
				String role=request.getParameter("role");
				String user_name=request.getParameter("user_name");
				String mobile_no=request.getParameter("mobile_no");
				String phone=request.getParameter("phone");
				String address=request.getParameter("address");
				String email=request.getParameter("email");
				
				HashMap<String,String> userDetails=new HashMap<>();
				
			
				userDetails.put("password",password);
				userDetails.put("role",role);
				userDetails.put("user_name",user_name);
				userDetails.put("mobile_no",mobile_no);
				userDetails.put("phone",phone);
				userDetails.put("address",address);
				userDetails.put("email",email);
				
				try {
					hotelService.addUsers(userDetails);
					
					RequestDispatcher rd=request.getRequestDispatcher("ViewHotels.jsp");
					rd.forward(request, response);
					
				} catch (UsersException e) {
					
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
				break;
			}  //end of case add....
			
			
			case "cityview" : {
				String hotel_id = "A101";
				
				 try {
					Hotel hotelDetails = 
							 hotelService.searchHotel(hotel_id);
					
					System.out.println("in cityviewcont "+hotelDetails);
					
					RequestDispatcher rd =
							request.getRequestDispatcher("HotelDetails.jsp");
					
					request.setAttribute("hotelDetails", hotelDetails);
					
					rd.forward(request, response);
					break;
				
				
				 }catch (HotelException e) {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", e.getMessage());
					
					rd.forward(request, response);
					break;
				}
				 
			} //end of case cityview...
			
			

			
			
			
			 case "login": {
				
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				
//				System.out.println(username);
				
				try {
					if(hotelService.validateUser(username, password)
							== true) {
//						HttpSession session = 
//								request.getSession(true);
//						
//						session.setAttribute("username", username);
				
						RequestDispatcher rd =
								request.getRequestDispatcher("ViewHotels.jsp");
						
						rd.forward(request, response);
						break;
				
					} else {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", "User with"+ username + "does not exsist");
					rd.forward(request, response);
					break;
					
				}
				
				} catch (UsersException e) {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", e.getMessage());
					
					rd.forward(request, response);
				
					break;
			}
				
		}
			
			
			
			default:
			{
				RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage","The page you requested does not exist");
				rd.forward(request, response);
				break;
			}
			
		}	
	}


}
