package com.capgemini.cheapstays.factory;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil {
	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Connection connection=null;
		
		try {
			InitialContext context=new InitialContext();
			
			DataSource source= (DataSource) context.lookup("java:/OracleDS1");
			
			connection =source.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return connection;

		
	}
	
	public static void main(String[] args)
	{
		try {
			Connection con=getConnection();
			System.out.println(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
