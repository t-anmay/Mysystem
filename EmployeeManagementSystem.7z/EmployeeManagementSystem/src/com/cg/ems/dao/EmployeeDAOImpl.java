package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;








import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.factory.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public void addEmployee(Employee emp) throws EmployeeException {
		
		
		try (Connection con = DBUtil.getConnection()) {
			PreparedStatement pstm =
					con.prepareStatement("insert into Employee values(employee_seq.nextval,?,?,?,?,?,?)");
			
		/*	pstm.setInt(1, emp.getId());*/
			pstm.setString(1, emp.getName());
			pstm.setString(2, emp.getDepartment());
			pstm.setString(3, emp.getDesignation());
			pstm.setString(4, emp.getDateOfBirth());
			pstm.setString(5, emp.getDateOfJoining());
			pstm.setFloat(6, emp.getSalary());
			
			pstm.executeUpdate();
			
			
			
	 } catch (Exception e) {
		e.printStackTrace();
	}
		
		
	}

	@Override
	public void updateEmployee(Employee emp) throws EmployeeException {
		
		try (Connection con = DBUtil.getConnection()){
			
			PreparedStatement pstm =
					con.prepareStatement("update Employee set name=?,department=?,designation=?,dateOfBirth=?,dateOfJoining =?,salary=? where id=?");   
															
			
			pstm.setString(1, emp.getName());
			pstm.setString(2, emp.getDepartment());
			pstm.setString(3, emp.getDesignation());
			pstm.setString(4, emp.getDateOfBirth());
			pstm.setString(5, emp.getDateOfJoining());
			pstm.setFloat(6, emp.getSalary());
			pstm.setInt(7, emp.getId());
			
			pstm.executeUpdate();
		
		
		
		
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
				
	
		
	}

	@Override
	public Employee searchEmployee(Employee emp) throws EmployeeException {
		
		try (Connection con = DBUtil.getConnection()){
			
			PreparedStatement pstm = 
					con.prepareStatement("select * from employee where id=?");
			
			pstm.setInt(1, emp.getId());
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() != true) {
				throw new EmployeeException("Employee not found with this id");
			}
			
			else {	
				emp.setId(res.getInt(1));
				emp.setName(res.getString(2));
				emp.setDepartment(res.getString(3));
				emp.setDesignation(res.getString(4));
				emp.setDateOfBirth(res.getString(5));
				emp.setDateOfJoining(res.getString(6));
				emp.setSalary(res.getFloat(7));
				
				}
			
		
		} catch (Exception e) {
			throw new EmployeeException(e);
			
		} 
		
		return emp;
	}

	
	
	@Override
	public void removeEmployee(Employee emp) throws EmployeeException {
		
		try (Connection con = DBUtil.getConnection()){
			
			try {
				searchEmployee(emp);
			
			} catch(Exception e) {
				throw new EmployeeException(e.getMessage());
			}
			
			PreparedStatement pstm = 
					con.prepareStatement("delete from employee where id=?");
			
			pstm.setInt(1, emp.getId());
			
			pstm.executeUpdate();
		
		
		} catch(Exception e) {
			throw new EmployeeException(e);
		} 
			
		
		
		
		
		
	}

	@Override
	public List<Employee> getAllEmployee() {
		
		ArrayList<Employee> employees = new ArrayList<>();
		
		try (Connection con = DBUtil.getConnection()) {
			
			Statement stml = con.createStatement();
			ResultSet res = stml.executeQuery("select * from employee");
				
			while(res.next()) {
				Employee emp = new Employee();
				
				emp.setId(res.getInt(1));
				emp.setName(res.getString(2));
				emp.setDepartment(res.getString(3));
				emp.setDesignation(res.getString(4));
				emp.setDateOfBirth(res.getString(5));
				emp.setDateOfJoining(res.getString(6));
				emp.setSalary(res.getFloat(7));
				
				employees.add(emp);
			}
			
			
			
		
		} catch(Exception e) {
			throw new EmployeeException(e);
		} 
		
		
		
		return employees;
	}
	
	
	
		
	

}
