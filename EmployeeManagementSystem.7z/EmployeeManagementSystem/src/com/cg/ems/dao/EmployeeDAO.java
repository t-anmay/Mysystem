package com.cg.ems.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeDAO {
	
	public void addEmployee(Employee emp) throws EmployeeException;
	public void updateEmployee(Employee emp) throws EmployeeException;
	public Employee searchEmployee(Employee emp) throws EmployeeException;
	public void removeEmployee(Employee emp) throws EmployeeException;
	public List<Employee> getAllEmployee() throws EmployeeException;

}
