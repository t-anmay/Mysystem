package com.cg.ems.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		
			Connection con = null;
			
			InitialContext context;
			try {
				context = new InitialContext();
				
				DataSource source = (DataSource)
						context.lookup("java:/OracleDS/MyDs");
				
				con = source.getConnection();
				
			
			
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
		
					
			
		return con;
		
		
	}
	
	/*
	public static void main(String[] args) {
		
		Connection con;
		try {
			con = getConnection();
			
			System.out.println(con);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		
		
		
	}

	}*/
}

