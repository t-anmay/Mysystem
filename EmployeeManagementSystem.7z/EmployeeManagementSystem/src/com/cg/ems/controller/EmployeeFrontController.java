package com.cg.ems.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.exception.UserException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;


@WebServlet("/EmployeeFrontController")
public class EmployeeFrontController extends HttpServlet {
	
	private EmployeeService employeeService;
       
    
    public EmployeeFrontController() {
        
    	employeeService = new EmployeeServiceImpl();    //association
        
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession userSession = request.getSession(false);
		
		if(userSession == null) {
			RequestDispatcher rd =
					request.getRequestDispatcher("Error.jsp");
		
			request.setAttribute("errorMessage", "You need to login first.<a href = 'Login.jsp'>Click Here </a> to login");
			rd.forward(request, response);
			return;
		
		
		
		}
		
		
		
		
		
		
		
		String action = request.getParameter("value");
		
		switch(action) {
		
		case "add": {
			
			//String id =request.getParameter("id");
			String name =request.getParameter("name");
			String dept =request.getParameter("department");
			String desg =request.getParameter("designation");
			String dob =request.getParameter("dateofbirth");
			String doj =request.getParameter("dateofjoining");
			String salary =request.getParameter("salary");
			
			HashMap<String , String> empDetails = 
					new HashMap<>();
			
	//		empDetails.put("id" ,  id);
			empDetails.put("name" ,  name);
			empDetails.put("department" ,  dept);
			empDetails.put("designation" ,desg);
			empDetails.put("dateofbirth" ,  dob);
			empDetails.put("dateofjoining" ,  doj);
			empDetails.put("salary" ,  salary);
			
			
			
		try {
			employeeService.addEmployee(empDetails);
			RequestDispatcher rd =
					request.getRequestDispatcher("menu.jsp");
			rd.forward(request, response);
			
		
		} catch (EmployeeException e) {
			RequestDispatcher rd =
					request.getRequestDispatcher("Error.jsp");
			
			request.setAttribute("errorMessage", e.getMessage());
			
			rd.forward(request, response);
		}
			
		
		break;
		} //end of case1
		
		case "fetch": {
			
			
			String id = request.getParameter("id");
			try {
				HashMap<String, String> empDetails = 
						employeeService.searchEmployee(id);
				
				RequestDispatcher rd =
						request.getRequestDispatcher("Update.Employee.jsp");
				
				request.setAttribute("empDetails", empDetails);
				
				rd.forward(request, response);
			
			}catch (EmployeeException e) {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", e.getMessage());
				
				rd.forward(request, response);
			}
			
			break;
		} //end of case2
		
		
		
		case "update": {
			
			String id =request.getParameter("id");
			String name =request.getParameter("name");
			String dept =request.getParameter("department");
			String desg =request.getParameter("designation");
			String dob =request.getParameter("dateofbirth");
			String doj =request.getParameter("dateofjoining");
			String salary =request.getParameter("salary");
			
			HashMap<String , String> empDetails = 
					new HashMap<>();
			
			empDetails.put("id" ,  id);
			empDetails.put("name" ,  name);
			empDetails.put("department" ,  dept);
			empDetails.put("designation" ,desg);
			empDetails.put("dateofbirth" ,  dob);
			empDetails.put("dateofjoining" ,  doj);
			empDetails.put("salary" ,  salary);
			
			try {
				employeeService.updateEmployee(empDetails);
				RequestDispatcher rd =
						request.getRequestDispatcher("menu.jsp");
				rd.forward(request, response);
				
			
			} catch (EmployeeException e) {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", e.getMessage());
				
				rd.forward(request, response);
			}
			
			
			
			
			break;
		} //end of case2
		
		case "search": {
			

			String id = request.getParameter("id");
			try {
				HashMap<String, String> empDetails = 
						employeeService.searchEmployee(id);
				
				RequestDispatcher rd =
						request.getRequestDispatcher("SearchEmployee.jsp");
				
				request.setAttribute("empDetails", empDetails);
				
				rd.forward(request, response);
			
			}catch (EmployeeException e) {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", e.getMessage());
				
				rd.forward(request, response);
			}
			
			
	
			break;
		} //end of case3


		case "remove": {
			
			String id = request.getParameter("id");
			try {
				employeeService.removeEmployee(id);
				
				
				RequestDispatcher rd =
						request.getRequestDispatcher("menu.jsp");
				
				rd.forward(request, response);
			
			}catch (EmployeeException e) {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", e.getMessage());
				
				rd.forward(request, response);
			}
	
	
			break;
		} //end of case4


		case "showall": {
			
		try {
		
			List<HashMap<String, String>> empl =
					employeeService.getAllEmployee();
			
			
			
			RequestDispatcher rd =
					request.getRequestDispatcher("ViewAllEmployee.jsp");
			
			request.setAttribute("employees", empl);
			
			rd.forward(request, response);
			break;
	
	
		
		}catch (EmployeeException e) {
			RequestDispatcher rd =
					request.getRequestDispatcher("Error.jsp");
			
			request.setAttribute("errorMessage", e.getMessage());
			
			rd.forward(request, response);
			break;
		}
	
			
		} //end of case5
		
		case "login": {
			
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			try {
				if(employeeService.validateUser(username, password)
						== true) {
					HttpSession session = 
							request.getSession(true);
					
					session.setAttribute("username", username);
					
					RequestDispatcher rd =
							request.getRequestDispatcher("menu.jsp");
					
					rd.forward(request, response);
					break;
			} else {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", "User with"+ username + "does not exsist");
				rd.forward(request, response);
				break;
				
			}
			
			} catch (UserException e) {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", e.getMessage());
				
				rd.forward(request, response);
				break;
				
			}
		
			
			
		}
		case "Logout" : {
			HttpSession session = request.getSession(false);
			
			if(session != null) {
				session.invalidate();
			}
			RequestDispatcher rd =
					request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
			break;
			
		}
		
		default : 
			RequestDispatcher rd =
				request.getRequestDispatcher("error.jsp");
			request.setAttribute("erroeMessage", "The page does not exsist");
			rd.forward(request, response);
			break;
			
			
			
			
		
		
		}
		
	}
}
