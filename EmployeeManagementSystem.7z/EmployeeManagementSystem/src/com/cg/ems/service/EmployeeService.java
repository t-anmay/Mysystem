package com.cg.ems.service;

import java.util.HashMap;
import java.util.List;

import com.cg.ems.dto.User;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.exception.UserException;

public interface EmployeeService {
	
	public void addEmployee(HashMap<String, String> empDetails) throws EmployeeException;
	public void updateEmployee(HashMap<String, String> empDetails) throws EmployeeException;
	public HashMap<String, String> searchEmployee(String id) throws EmployeeException;
	public void removeEmployee(String id) throws EmployeeException;
	public List<HashMap<String, String>> getAllEmployee() throws EmployeeException;
	
	public boolean validateUser(String username, String password) throws UserException;
}
