package com.cg.ems.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.ems.dao.EMSUsersDAO;
import com.cg.ems.dao.EMSUsersDAOImpl;
import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.EmployeeDAOImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.User;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.exception.UserException;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDAO employeeDAO;
	
	private EMSUsersDAO emsUsersDAO;
	
	
	public EmployeeServiceImpl() {
		employeeDAO = new EmployeeDAOImpl();
		 emsUsersDAO = new EMSUsersDAOImpl();
	}
	
	

	@Override
	public void addEmployee(HashMap<String, String> empDetails)
			throws EmployeeException {
		
		System.out.println(empDetails);
		
		Employee emp  =new Employee();
		//emp.setId(Integer.parseInt(empDetails.get("id")));
		
		emp.setName(empDetails.get("name"));
		emp.setDepartment(empDetails.get("department"));
		emp.setDesignation(empDetails.get("designation"));
		emp.setDateOfBirth(empDetails.get("dateofbirth"));
		emp.setDateOfJoining(empDetails.get("dateofjoining"));
		emp.setSalary(Float.parseFloat(empDetails.get("salary")));
		
		employeeDAO.addEmployee(emp);
	
		
	}

	@Override
	public void updateEmployee(HashMap<String, String> empDetails)
			throws EmployeeException {
		System.out.println("hi............................................");
		System.out.println(empDetails);
		
		Employee emp  =new Employee();
		
		emp.setId(Integer.parseInt(empDetails.get("id")));
		emp.setName(empDetails.get("name"));
		emp.setDepartment(empDetails.get("department"));
		emp.setDesignation(empDetails.get("designation"));
		emp.setDateOfBirth(empDetails.get("dateofbirth"));
		emp.setDateOfJoining(empDetails.get("dateofjoining"));
		emp.setSalary(Float.parseFloat(empDetails.get("salary")));
		
		employeeDAO.updateEmployee(emp);
	
		
	}

	@Override
	public HashMap<String, String> searchEmployee(String id)
			throws EmployeeException {
		
		Employee emp = new Employee();
		emp.setId(Integer.parseInt(id));
		
		emp = employeeDAO.searchEmployee(emp);
		
		HashMap<String, String> empDetails = new HashMap<>();
		
		empDetails.put("id", emp.getId() + "");
		empDetails.put("name",emp.getName());
		empDetails.put("department", emp.getDepartment() );
		empDetails.put("designation", emp.getDesignation());
		empDetails.put("dateofbirth", emp.getDateOfBirth() );
		empDetails.put("dateofjoining", emp.getDateOfJoining() );
		empDetails.put("salary", emp.getSalary() + "");
	
		return empDetails;
	}

	@Override
	public void removeEmployee(String id) throws EmployeeException {
		
		Employee emp = new Employee();
		emp.setId(Integer.parseInt(id));
		
		employeeDAO.removeEmployee(emp);
	
		
	}

	@Override
	public List<HashMap<String, String>> getAllEmployee() {
		
		ArrayList<HashMap<String, String>> employees =
				new ArrayList<>();
		
		List<Employee> emps = employeeDAO.getAllEmployee();
		
		for (int index = 0; index < emps.size(); index++) {
			
			Employee emp = emps.get(index);
			
			HashMap<String, String> empDetails = new HashMap<>();
			
			empDetails.put("id", emp.getId() + "");
			empDetails.put("name",emp.getName());
			empDetails.put("department", emp.getDepartment() );
			empDetails.put("designation", emp.getDesignation());
			empDetails.put("dateofbirth", emp.getDateOfBirth() );
			empDetails.put("dateofjoining", emp.getDateOfJoining() );
			empDetails.put("salary", emp.getSalary() + "");
			
			employees.add(empDetails);
		}
			return employees; 
	}



	@Override
	public boolean validateUser(String username, String password)
			throws UserException {
		User user = new User(username,password);
		
	

	return emsUsersDAO .validateUser(user);	
		
	}



	

}
