package com.cg.ems.exception;

public class EmployeeException extends RuntimeException {

	public EmployeeException() {
		super();
		
	}

	public EmployeeException(String message) {
		super(message);
		
	}

	public EmployeeException(Throwable cause) {
		super(cause);
		
	}
	
	

}
