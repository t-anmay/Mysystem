drop table Employee Cascade contraints;

create table Employee(
	 id int,
	 name varchar2(20),
	department varchar2(20),
	 designation varchar2(20),
	 dateOfBirth varchar2(12),
	 dateOfJoining varchar2(12),
 	salary float
);
commit;

create table EMSUsers(
	id int,
	username varchar2(20),
	password varchar2(20)
)
commit;