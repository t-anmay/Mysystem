package com.capgemini.cheapstays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.capgemini.cheapstays.dto.Order;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.factory.DBUtil;

public class RoomDAOImpl implements RoomsDAO {

	@Override
	public Room roomDetails(Order order) throws RoomException {
		return null;
		
//		try (Connection con = DBUtil.getConnection()){
//			
//			PreparedStatement pstm = 
//					con.prepareStatement("select * from roomdetails where hotel_id=? and room_id=?");
//		
//	
//}	
}

	@Override
	public void addRoom(Room room) throws RoomException {
	try(Connection con=DBUtil.getConnection()) {
			
		PreparedStatement pstm=con.prepareStatement("INSERT INTO roomdetails values(?,?,?,?,?,?)");
		
		pstm.setString(1, room.getHotel_id());
		pstm.setString(2, room.getRoom_id());
		pstm.setString(3, room.getRoom_no()); 
		pstm.setString(4, room.getRoom_type());
		pstm.setDouble(5, room.getPer_night_rate());
		pstm.setString(6, room.getAvailability());
			
			pstm.executeUpdate();
			
			
		} catch (Exception e) {
			throw new RoomException(e);
		}
		
	}

	@Override
	public void updateRoom(Room room) throws RoomException {
		
		try(Connection con= DBUtil.getConnection())
		{
			PreparedStatement pstm =con.prepareStatement("UPDATE roomdetails SET room_no=?,room_type=?,per_night_rate=?,availability=? where hotel_id=? and room_id=?");
			
		
			pstm.setString(1, room.getRoom_no());
			pstm.setString(2, room.getRoom_type());
			pstm.setDouble(3, room.getPer_night_rate());
			pstm.setString(4, room.getAvailability());
			pstm.setString(5, room.getHotel_id());
			pstm.setString(6, room.getRoom_id());
			
			pstm.executeUpdate();
		}
		catch(Exception e){
			throw new RoomException(e);
			
		}
	}


	@Override
	public void deleteRoom(Room room) throws RoomException {
		try(Connection con= DBUtil.getConnection())
		{
		PreparedStatement ps= con.prepareStatement("delete from roomdetails WHERE room_id=?");

				ps.setString(1,room.getRoom_id());
				ps.execute();
			}
			catch(Exception e)
				{
				throw new RoomException(e);
			}
		
	}
}