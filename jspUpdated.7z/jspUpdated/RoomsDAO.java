package com.capgemini.cheapstays.model.dao;

import com.capgemini.cheapstays.dto.Order;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.exception.RoomException;


public interface RoomsDAO {
	
	public Room roomDetails(Order order) throws RoomException;
    public void addRoom(Room room) throws RoomException;
    public void updateRoom(Room room) throws RoomException;
    public void deleteRoom(Room room) throws RoomException;
    
} 
