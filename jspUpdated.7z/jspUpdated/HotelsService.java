package com.capgemini.cheapstays.service;

import java.util.HashMap;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Order;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.exception.UsersException;


public interface HotelsService {
	
	
	//for hotel 
	public Hotel searchHotel(String hotel_id) throws HotelException;
	
	public void addUsers(Users user) throws UsersException;
	
	public boolean validateUser(String username, String password) throws UsersException;
	
	//public Room roomDetails(String noOfRooms ,String typeOfRooms) throws RoomException;
	
	public Room roomDetails(String noOfRoom, String typeOfRooms) throws RoomException;
    public void addRoom(Room room) throws RoomException;
    public void updateRoom(Room room) throws RoomException;
    public void deleteRoom(String room_id) throws RoomException;
}
