package com.capgemini.cheapstays.service;

import java.util.HashMap;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Order;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.model.dao.HotelsDAO;
import com.capgemini.cheapstays.model.dao.HotelsDAOImpl;
import com.capgemini.cheapstays.model.dao.RoomDAOImpl;
import com.capgemini.cheapstays.model.dao.RoomsDAO;
import com.capgemini.cheapstays.model.dao.UsersDAO;
import com.capgemini.cheapstays.model.dao.UsersDAOImpl;


public class HotelsServiceImpl implements HotelsService {
	
	private UsersDAO usersDAO;
	private HotelsDAO hotelDAO;
	private RoomsDAO roomDAO;
	
	public HotelsServiceImpl() {
		usersDAO=new UsersDAOImpl();
		hotelDAO =new HotelsDAOImpl();
		roomDAO = new RoomDAOImpl();
	}

	@Override
	public void addUsers(Users user)
			throws UsersException {
				usersDAO.addUsers(user);
			} //end of addUsers...

	@Override
	public boolean validateUser(String username, String password) throws UsersException {
		
		Users user=new Users();
		user.setUser_name(username);
		user.setPassword(password);
	
		return usersDAO.validateUser(user);
	} //end of validateUsers....

	
	
	@Override
	public Hotel searchHotel(String hotel_id) throws HotelException {
		
			Hotel hotel = new Hotel();
			hotel.setHotel_id(hotel_id);
			
			Hotel foundHotel = hotelDAO.searchHotel(hotel);
			System.out.println("IN service foundHotel " +foundHotel);
			return foundHotel;
		
	}// end oh hotel search...

	@Override
	public Room roomDetails(String noOfRoom , String typeOfRooms) throws RoomException {
		return null;
	}

	@Override
	public void addRoom(Room room) throws RoomException {
		roomDAO.addRoom(room);
		
	} // end of add rooms

	
	@Override
	public void updateRoom(Room room) throws RoomException {
		roomDAO.updateRoom(room);
		
	} // end of update rooms
	

	@Override
	public void deleteRoom(String room_id) throws RoomException {
		Room room = new Room();
		room.setRoom_id(room_id);
		roomDAO.deleteRoom(room);
		
	} // end of delete rooms

//	@Override
//	public Room roomDetails(String noOfRooms, String typeOfRooms)
//			throws RoomException {
//		
//		Order order = new Order();
//		
//		order.setNoOfRooms(noOfRooms);
//		order.setTypeOfRooms(typeOfRooms);
//	
//		return roomDAO.roomDetails(order);
//		
//	
//	}

}
