package com.capgemini.cheapstays.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Order;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.service.HotelsService;
import com.capgemini.cheapstays.service.HotelsServiceImpl;


@WebServlet("/UsersFrontController")
public class UsersFrontController extends HttpServlet {
	
	private HotelsService hotelService;
       
  
    public UsersFrontController() {
    	hotelService = new HotelsServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//	HttpSession usersession = request.getSession(false);
		
//		if(usersession == null)
//		{
//			RequestDispatcher rd= request.getRequestDispatcher("Error.jsp");
//			request.setAttribute("errorMessage", "You need to login to access this page."+"<a href='Login.jsp'>Click Here</a> to login.");
//			rd.forward(request, response);
//			return;
//		}
		
		
		
		
		String action = request.getParameter("action");
		
		switch(action)
		{
			case "adduser":
			{
				
				String password=request.getParameter("password");
				String role=request.getParameter("role");
				String user_name=request.getParameter("user_name");
				String mobile_no=request.getParameter("mobile_no");
				String phone=request.getParameter("phone");
				String address=request.getParameter("address");
				String email=request.getParameter("email");
				Users user = new Users();
				user.setPassword(password);
				user.setRole(role);
				user.setUser_name(user_name);
				user.setMobile_no(mobile_no);
				user.setPhone(phone);
				user.setAddress(address);
				user.setEmail(email);
		
				
				try {
					hotelService.addUsers(user);
					
					RequestDispatcher rd=request.getRequestDispatcher("MainOptions.jsp");
					rd.forward(request, response);
					
				} catch (UsersException e) {
					
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
				break;
			}  //end of case add....
			
			
			case "cityview" : {
				String hotel_id = "A101";
				
				System.out.println(hotel_id);
				 try {
					Hotel hotelDetails = 
							 hotelService.searchHotel(hotel_id);
					
					System.out.println("in cityviewcont "+hotelDetails);
					
					RequestDispatcher rd =
							request.getRequestDispatcher("Jsp/HotelDetails.jsp");
					
					request.setAttribute("hotelDetails", hotelDetails);
					
					rd.forward(request, response);
					break;
				
				
				 }catch (HotelException e) {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", e.getMessage());
					
					rd.forward(request, response);
					break;
				}
				 
			} //end of case cityview...
			
			case  "mountview" : {
				String hotel_id = "A102";
				
				 try {
					Hotel hotelDetails = 
							 hotelService.searchHotel(hotel_id);
					
					System.out.println("in cityviewcont "+hotelDetails);
					
					RequestDispatcher rd =
							request.getRequestDispatcher("HotelDetails.jsp");
					
					request.setAttribute("hotelDetails", hotelDetails);
					
					rd.forward(request, response);
					break;
				
				
				 }catch (HotelException e) {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", e.getMessage());
					
					rd.forward(request, response);
					break;
				}
				 
			} //end of case cityview...
			
				
			
			 case "login": {
				
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				
//				System.out.println(username);
				
				try {
					if(hotelService.validateUser(username, password)
							== true) {
//						HttpSession session = 
//								request.getSession(true);
//						
//						session.setAttribute("username", username);
				
						RequestDispatcher rd =
								request.getRequestDispatcher("MainOptions.jsp");
						
						rd.forward(request, response);
						break;
				
					} else {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", "User with"+ username + "does not exsist");
					rd.forward(request, response);
					break;
					
				}
				
				} catch (UsersException e) {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", e.getMessage());
					
					rd.forward(request, response);
				
					break;
			}
				
		} //end of case login....
			
			 case "bookroom": {
				 
				 String noOfRooms = request.getParameter("numberofrooms");
				 String typeOfRooms = request.getParameter("roomtype");
				 
				 Order order = new Order(noOfRooms, typeOfRooms);
				 try {
					hotelService.roomDetails(noOfRooms, typeOfRooms);
				
				 
				 
				 
				 } catch (RoomException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 } //end of book room
				 
				 case "addRoom": {
					 String hotel_Id = request.getParameter("hotel_Id");
					 String room_id = request.getParameter("room_Id");
					 String room_no = request.getParameter("room_No");
					 String room_type = request.getParameter("roomtype");
					 double per_night_rate = Double.parseDouble(request.getParameter("PER_NIGHT_RATE"));
					 String availability= request.getParameter("Availability");
					 
					 Room room = new Room();
					 room.setHotel_id(hotel_Id);
					 room.setRoom_id(room_id);
					 room.setRoom_no(room_no);
					 room.setRoom_type(room_type);
					 room.setPer_night_rate(per_night_rate);
					 room.setAvailability(availability);
					 
					 try{
						hotelService.addRoom(room);
						RequestDispatcher rd=request.getRequestDispatcher("MainOptionsAdmin.jsp");
						rd.forward(request, response);
						
					} catch (RoomException e) {
						
						RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMessage", e.getMessage());
						rd.forward(request, response);
					}
					break;
				}  //end of add room
				 
				 
					 
				 case "updateRoom":  {
					 
					 String hotel_Id = request.getParameter("hotel_Id");
					 String room_id = request.getParameter("room_id");
					 String room_no = request.getParameter("room_no");
					 String room_type = request.getParameter("room_type");
					 double per_night_rate =Double.parseDouble(request.getParameter("PER_NIGHT_RATE"));
					 String availability= request.getParameter("availability");
					 
					 Room room = new Room();
					 room.setHotel_id(hotel_Id);
					 room.setRoom_id(room_id);
					 room.setRoom_no(room_no);
					 room.setRoom_type(room_type);
					 room.setPer_night_rate(per_night_rate);
					 room.setAvailability(availability);
					 
					 try{
							hotelService.updateRoom(room);;
							RequestDispatcher rd=request.getRequestDispatcher("MainOptionsAdmin.jsp");
							rd.forward(request, response);
							
						} catch (RoomException e) {
							
							RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
							request.setAttribute("errorMessage", e.getMessage());
							rd.forward(request, response);
						}
						break;
					 
				 }  //end of update Room
				 
				 case "deleteRoom":	{
					 
					 String room_id = request.getParameter("Room_Id");
					 try {
							hotelService.deleteRoom(room_id);
							RequestDispatcher rd = request.getRequestDispatcher("MainOptionsAdmin.jsp");
							
							
							rd.forward(request, response);
						
						} 
						catch (RoomException e) {
							
							RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
							
							request.setAttribute("errorMessage", e.getMessage());
							rd.forward(request, response);
						}
					 
					 
				 }default:
					{
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMessage","The page you requested does not exist");
						rd.forward(request, response);
						break;
					}
//				try {
//					
//					Room room = 
//							 hotelService.roomDetails(hotel_id, room_id); 
//					
//					RequestDispatcher rd =
//							request.getRequestDispatcher("BookingDetails.jsp");
//					
//					request.setAttribute("room", room);
//					
//					rd.forward(request, response);
//					break;
//					
//					
//					
//				} catch (Exception e) {
//					RequestDispatcher rd =
//							request.getRequestDispatcher("Error.jsp");
//					
//					request.setAttribute("errorMessage", e.getMessage());
//					
//					rd.forward(request, response);
//					break;
//				}
				 
				 
				 
				 
				 
				 
				 
				 
			 } //end of bookroom....
			
			
			
		}	
	}


